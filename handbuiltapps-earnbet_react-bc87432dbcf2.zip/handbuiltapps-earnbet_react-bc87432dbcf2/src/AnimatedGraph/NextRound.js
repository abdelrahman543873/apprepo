import React from 'react';

export default class NextRound extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            i: props.number
        }
        this.timer = 0;
    }

    componentDidMount() {
        this.animateNumber();
    }

    componentDidUpdate(prevProps) {
        const { number } = this.props;
        if (prevProps.number !== number) {
            this.setState({
                i: number
            }, () => {
                this.animateNumber();
            })
        }
    }

    componentWillUnmount() {
        clearTimeout(this.timer);
    }

    animateNumber = () => {
        const { i } = this.state;
        const { onCountdownFinished, onNumberChange } = this.props;
        if (i < 1) {
            onCountdownFinished();
            return false;
        }
        this.timer = setTimeout(() => {
            this.setState({
                i: i - 1
            }, () => {
                onNumberChange(this.state.i);
                this.animateNumber();
            })
        }, 1000)
    }

    render() {
        const { i } = this.state;
        return (
            <>{i}</>
        )
    }
}