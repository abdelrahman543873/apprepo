import React from 'react';
import { SequenceAnimator } from 'react-sequence-animator';

export default class ImageSequence extends React.Component {
    importAll = (r) => {
        let images = {};
        r.keys().map(item => { images[item.replace('./', '')] = r(item); });
        return images;
    }

    render() {
        const { attribute, r, loop = true, onSequenceEnd = () => {} } = this.props;
        let images = this.importAll(r);
        return (
            <SequenceAnimator loop={loop} duration={500} onSequenceEnd={onSequenceEnd}>
                {
                    Object.keys(images).map((item, i) => (
                        <img src={images[item].default} key={`${attribute}_1${i}`} />
                    ))
                }
            </SequenceAnimator>
        )
    }
}