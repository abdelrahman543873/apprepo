import React from 'react';
import $ from 'jquery';

import NextRound from './NextRound';
import ImageSequence from './ImageSequence';
import AnimatedNumber from './AnimatedNumber';

import style from './style.css'
import bg from './images/bg.png';

export default class AnimatedGraph extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            countdown: props.countdown || 3,
            nextround: props.countdown || 3,
            animate: false,
            crashed: false,
            explode: false,
            number: 0,
            line: []
        }
    }

    componentDidMount() {
        //Image preloading
        this.imagesList = [bg];
        this.imagesLoaded = 0;
        this.maxVelocity = 2;
        this.interval = 0;
        this.timer = 0;
        this.sequences = {};
        this.time = 0;

        //Import sequences
        this.importAll("rocket_cyan", require.context('./images/rocket_cyan', false, /\.png$/));
        this.importAll("rocket_gold", require.context('./images/rocket_gold', false, /\.png$/));
        this.importAll("rocket_silver", require.context('./images/rocket_silver', false, /\.png$/));
        this.importAll("rocket_purple", require.context('./images/rocket_purple', false, /\.png$/));
        this.importAll("parachutte", require.context('./images/parachutte', false, /\.png$/));
        this.importAll("clouds", require.context('./images/clouds', false, /\.png$/));
        this.importAll("moon", require.context('./images/moon', false, /\.png$/));
        this.importAll("saturn", require.context('./images/saturn', false, /\.png$/));
        this.importAll("rock1", require.context('./images/rock1', false, /\.png$/));
        this.importAll("rock2", require.context('./images/rock2', false, /\.png$/));
        this.importAll("rock3", require.context('./images/rock3', false, /\.png$/));
        this.importAll("rock4", require.context('./images/rock4', false, /\.png$/));
        this.importAll("satelite", require.context('./images/satelite', false, /\.png$/));
        this.importAll("fire1", require.context('./images/fire1', false, /\.png$/));
        this.importAll("fire2", require.context('./images/fire2', false, /\.png$/));
        this.importAll("explosion", require.context('./images/explosion', false, /\.png$/));

        //Global variables
        this.ctx = $('.crashGraph canvas')[0].getContext("2d");
        this.canvas = $('.crashGraph canvas')[0];
        this.canvasWidth = $('.crashGraph').outerWidth();
        this.canvasHeight = $('.crashGraph').outerHeight();
        this.bgWidth = 1300;
        this.bgHeight = 2664 * this.bgWidth / 4302;
        this.cloudHeight = 987 * this.bgWidth / 1600;
        this.rocketWidth = 455;
        this.rocketHeight = 250;
        this.canvasX = 0;
        this.canvasX = 0;
        this.canvasY = 0;
        this.rocketX = -150;
        this.rocketY = this.canvasHeight - 190;
        this.moonX = 200;
        this.moonY = -200;
        this.rockWidth = 600;
        this.rockHeight = 1080 * this.rockWidth / 1920;
        this.rockY = 0;
        //Meteors
        this.meteorWidth = 500;
        this.meteorHeight = 1080 * this.meteorWidth / 1920;
        this.meteorX = this.meteorX1 = this.meteorX2 = this.canvasWidth;
        this.meteorY = this.meteorY1 = this.meteorY2 = this.saturnY = -this.meteorHeight;
        this.meteorMove = 1;
        //Saturn
        this.saturnX = 100;
        //Explosion
        this.explodeY = 0;
        this.spadeY = 0;
        this.setDimensions();
        this.preloadImages();
        //Y Axis
        this.yHeight = $('.crashAxisY').height();
        this.yEnd = 2.45;
        this.yDist = 0.05;
        this.yDiv = 4;
    }

    componentDidUpdate(prevProps) {

    }

    componentWillUnmount() {
        //window.cancelAnimationFrame(this.af);
    }

    importAll = (attribute, r, v = "") => {
        let images = {};
        r.keys().map(item => { images[item.replace('./', '')] = r(item); });
        this.sequences[attribute] = {
            images,
            i: 0,
            f: 0,
            e: r.keys().length
        }
    }

    setDimensions = () => {
        this.canvasWidth = $('.crashGraph').outerWidth();
        this.canvasHeight = $('.crashGraph').outerHeight();
        $('canvas').attr({
            width: this.canvasWidth,
            height: this.canvasHeight
        })
    }

    // The function to draw the scene
    draw = () => {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        this.drawBg();
        this.drawSequence("moon", this.moonX, this.moonY, this.rocketWidth / 1.2, this.rocketHeight / 1.2);
        this.drawSequence("fire1", this.meteorX1, this.meteorY1, this.meteorWidth, this.meteorHeight);
        this.drawSequence("fire2", this.meteorX2, this.meteorY2, this.meteorWidth, this.meteorHeight);
        this.drawSequence("rock1", 75, -this.rockHeight * 1.5 + this.rockY, this.rockWidth, this.rockHeight);
        this.drawSequence("rock2", 75, -this.rockHeight * 2 + this.rockY, this.rockWidth, this.rockHeight);
        this.drawSequence("rock3", 75, -this.rockHeight * 2.5 + this.rockY, this.rockWidth, this.rockHeight);
        this.drawSequence("rock4", 75, -this.rockHeight * 3 + this.rockY, this.rockWidth, this.rockHeight);
        this.drawSequence("satelite", -250, -this.rockHeight + this.rockY, this.rockWidth, this.rockHeight);
        this.drawSequence("saturn", this.saturnX, this.saturnY, this.rockWidth, this.rockHeight);
        this.ctx.fillStyle = "rgba(255,255,255, 0.01)";
        this.ctx.fillRect(0, 0, this.canvasWidth, this.canvasHeight);
    }

    drawLayer = (img, times1 = 1, times2 = 1) => {
        this.drawImage(img, this.canvasX, -1 * times1 * this.canvasHeight + this.canvasY, this.canvasWidth, this.canvasHeight);
        this.drawImage(img, this.canvasX + this.canvasWidth, -1 * times2 * this.canvasHeight + this.canvasY, this.canvasWidth, this.canvasHeight);
    }

    getRocketkey = () => {
        const { number } = this.state;
        if (number >= 100)
            return "rocket_gold";
        if (number >= 50)
            return "rocket_silver";
        if (number >= 10)
            return "rocket_purple";
        return "rocket_cyan";
    }

    drawRocket() {
        let ctx = this.ctx;
        ctx.save();
        var rad = (20 - (204 - this.rocketY) * 0.145985401459854) * Math.PI / 180;
        ctx.translate((this.rocketX + this.rocketWidth / 2) + ((204 - this.rocketY) * 0.111489051094891 / 2), this.rocketY + this.rocketHeight / 2);
        ctx.rotate(rad);
        var image_key = this.getRocketkey();
        ctx.drawImage($(`#${image_key}${this.getSequenceNumber(image_key, 1)}`)[0], -this.rocketWidth / 2, -this.rocketHeight / 2, this.rocketWidth, this.rocketHeight);
        ctx.restore();
    }

    drawSpade() {
        this.drawSequence("parachutte", -95 + this.rocketX, -75 + this.rocketY, 550, 310);
    }

    drawExplode() {
        this.drawSequence("explosion", 10 + this.rocketX, -30 + this.explodeY, 550, 310, 2, false);
    }

    drawSequence = (name, x, y, width, height, speed = 1, loop = true) => {
        let num = this.getSequenceNumber(name, speed, loop);
        if (num !== false) {
            this.drawImage(`${name}${num}`, x, y, width, height);
        }
    }

    getSequenceNumber = (name, speed, loop = true) => {
        let seq = this.sequences[name];
        let frames = seq.f;
        if (speed !== 1 && frames % speed !== 0) {
            this.sequences[name].f = frames + 1;
            return seq.i;
        }
        else {
            this.sequences[name].f = frames + 1;
        }
        let n = seq.i >= seq.e ? (loop === true ? 0 : false) : seq.i;
        if (n === false)
            return n;
        this.sequences[name].i = n + 1;
        return n;
    }

    drawImage = (id, x, y, width, height) => {
        let ctx = this.ctx;
        if ($(`#${id}`).length) {
            ctx.drawImage($(`#${id}`)[0], x, y, width, height);
        }
    }

    drawBg = () => {
        let ctx = this.ctx;
        let delta = this.canvasX * 3;
        var numImages = Math.ceil((Math.abs(delta) + this.canvasWidth) / this.bgWidth) + 1;
        for (var i = 0; i < numImages; i++) {
            if (delta + ((i + 1) * this.bgWidth) >= 0) {
                ctx.drawImage($(`#crashBg`)[0], i * this.bgWidth + delta, -1 * (this.bgHeight - this.canvasHeight) + this.canvasY, this.bgWidth, this.bgHeight);
                this.drawSequence("clouds", i * this.bgWidth + delta, -0.75 * this.cloudHeight + this.canvasY, this.bgWidth, this.cloudHeight, 10);
            }
        }
    }

    preloadImages = () => {
        this.imagesList.map(item => {
            this.loadImage(item);
        })
    }

    loadImage = (source) => {
        let image = new Image();
        image.src = source;
        if (image.complete || image.readystate === 4) {
            this.checkStart();
        }
        else {
            image.onload = () => {
                this.checkStart();
            }
            image.onerror = () => {
                //Unable to load image
                this.checkStart();
            }
        }
    }

    update = () => {
        const { crashed, number } = this.state;
        if (crashed === false) {
            // incrementally change image position of background to scroll left
            this.canvasX -= this.maxVelocity;
            this.bgX = this.canvasX;
            if (this.bgX < -this.canvasWidth) {
                this.bgX += this.canvasWidth;
            }
            if (this.rocketX < this.canvasWidth - 410) {
                this.rocketX += 10;
            }
            else {
                this.canvasY += 0.5;
            }
            if (this.rocketY > -45) {
                this.rocketY = this.canvasHeight - this.rocketHeight / 2 - (this.state.number / this.yDist) * (this.canvasHeight - 60) / (this.yEnd / this.yDist);
            }
            //Move moon
            if ((number >= 1 && number <= 4) || number >= 10) {
                this.moonX -= 0.4;
                this.moonY += 0.5;
            }
            //Rocks & Satellite
            if (number >= 10) {
                this.rockY += 1;
            }
            //Meteors
            if (number >= 18) {
                if (this.meteorMove === 1) {
                    this.meteorX1 -= 4;
                    this.meteorY1 += 2;
                    if (this.meteorY1 >= this.canvasHeight) {
                        this.meteorX2 = this.meteorX;
                        this.meteorY2 = this.meteorY;
                        this.meteorMove = 2;
                    }
                }
                else if (this.meteorMove === 2) {
                    this.meteorX2 -= 8;
                    this.meteorY2 += 4;
                    if (this.meteorY2 >= this.canvasHeight) {
                        this.meteorX1 = this.meteorX;
                        this.meteorY1 = this.meteorY;
                        this.meteorMove = 1;
                    }
                }
            }
            //Saturn
            if (number >= 23) {
                this.saturnX -= 0.05;
                this.saturnY += 0.3;
            }
        }
        else {
            this.canvasY -= 2;
            if (this.canvasY <= 0) {
                clearInterval(this.interval);
                clearInterval(this.timer);
            }
            this.rocketY += 2 * this.spadeY;
        }
    }

    drawAxisX = () => {
        $(".crashAxisX").html('');
        let spacer = (this.canvasWidth - 50) / this.time;
        for (var i = 1; i <= this.time; i++) {
            if ((this.time > 5 && i % 2 !== 0) || (this.time > 10 && i % 5 !== 0) || (this.time > 40 && i % 10 !== 0) || (this.time > 80 && i % 20 !== 0) || (this.time > 160 && i % 40 !== 0) || (this.time > 320 && i % 50 !== 0) || (this.time > 480 && i % 100 !== 0)) {
                continue;
            }
            $(".crashAxisX").append(`<div class="crashAxisXLine" style="transform: translateX(${i * spacer}px)"><div class="crashAxisXLineText">${i}s</div></div>`);
        }
    }

    drawAxisY = () => {
        $(".crashAxisY").html('');
        let spacer = (this.canvasHeight - 60) / ((this.yEnd - 1) / this.yDist);
        for (var i = 1, j = 0; i <= this.yEnd; i += this.yDist, j += 1) {
            console.log("axis", i.toFixed(), j * spacer);
            $(".crashAxisY").append(`<div class="crashAxisYLine${j % this.yDiv === 0 ? '' : ' subDiv'}" style="transform: translateY(-${j * spacer}px)"><div class="crashAxisYLineText">${i.toFixed(2)}x</div></div>`);
        }
    }

    drawLine = () => {
        const { line } = this.state;
        if (line.length > 0) {
            var ctx = this.ctx;
            var dist = (this.canvasWidth - 50) / line.length;
            ctx.beginPath();
            ctx.lineWidth = 0.5;
            ctx.strokeStyle = '#ffffff';
            ctx.moveTo(0, this.canvasHeight - 40);
            for (var i = 0; i < line.length; i++) {
                let y = this.canvasHeight - 40 - ((line[i] - 1) / this.yEnd) * this.yHeight;
                console.log("line", line[i], y);
                ctx.lineTo((i + 1) * dist, y);
                ctx.stroke();
            }
        }
    }

    redraw = () => {
        const { animate, crashed } = this.state;
        if (animate === true) {
            // Update the scene before drawing
            this.update();
            // Draw the scene
            this.draw();
            if (crashed === true) {
                this.drawExplode();
                this.drawSpade();
            }
            else {
                this.drawRocket();
                // Draw x-axis
                this.drawAxisX();
                // Draw y-axis
                this.drawAxisY();
                //Draw line
                this.drawLine();
            }
        }
    }

    checkStart = () => {
        this.imagesLoaded += 1;
        if (this.imagesLoaded >= this.imagesList.length) {
            this.setDimensions();
            this.draw();
            this.interval = setInterval(() => {
                this.redraw();
            }, 1000 / 33);
            this.timer = setInterval(() => {
                this.time += 1 / 33;
                this.yEnd += 0.002;
                if (this.state.number >= this.yEnd - 1) {
                    this.yEnd = this.state.number + 1;
                }
                if (this.yEnd > 100) {
                    this.yDist = 10;
                }
                if (this.yEnd > 75) {
                    this.yDist = 5;
                }
                else if (this.yEnd > 50) {
                    this.yDist = 2;
                }
                else if (this.yEnd > 30) {
                    this.yDist = 0.8;
                }
                else if (this.yEnd > 15) {
                    this.yDist = 0.4;
                }
                else if (this.yEnd > 8) {
                    this.yDist = 0.2;
                }
                else if (this.yEnd > 4) {
                    this.yDist = 0.1;
                }
                else if (this.yEnd > 2.5) {
                    this.yDist = 0.1;
                    this.yDiv = 5;
                }
            }, 1000 / 33);
        }
    }

    render() {
        const { crash } = this.props;
        const { countdown, animate, crashed, nextround, line } = this.state;
        return (
            <>
                <div className={`crashCanvas${crashed === true ? " crashed" : ""}`}>
                    <div className="crashCanvasSizer"></div>
                    <div className="crashGraph">
                        <canvas style={{ backgroundColor: `#182332` }}></canvas>
                    </div>
                    <div className={`crashTextWrap${nextround <= 1 ? ' crashRocketOut' : ""} ${animate !== true ? "showText" : "showGraph"}`}>
                        <div className='crashRocketStart'>
                            <ImageSequence attribute="rocket" r={require.context('./images/rocket_cyan', false, /\.png$/)} />
                        </div>
                        <div className="crashText crashRoundText">
                            <span>Next round in <NextRound number={countdown} onNumberChange={(nextround) => this.setState({ nextround })} onCountdownFinished={this.onCountdownFinished} />s</span>
                        </div>
                        <div className="crashText crashGraphNum">
                            {
                                animate === true && (
                                    <AnimatedNumber animate={crash} onNumberChange={(number) => this.setState({ number, line: [...line, number] })} onCrashed={this.onCrashed} />
                                )
                            }
                            <span>x</span>
                        </div>
                    </div>
                    <div className='crashAxisX'></div>
                    <div className='crashAxisY'></div>
                </div>
                <img src={bg} id="crashBg" style={{ display: 'none' }} />
                {
                    this.sequences && Object.entries(this.sequences).map(([key, value]) => (
                        Object.keys(value.images).map((item, i) => (
                            <img id={`${key}${i}`} src={value.images[item].default} alt={`${key}_${i}`} key={`${key}_${i}`} style={{ display: 'none' }} />
                        ))
                    ))
                }
            </>
        )
    }

    onExplosionFinished = () => {
        this.setState({
            explode: true
        })
    }

    onCountdownFinished = () => {
        this.setState({
            countdown: 0,
            animate: true
        })
    }

    onCrashed = () => {
        this.setState({
            crashed: true
        }, () => {
            this.explodeY = this.rocketY;
            this.spadeY = (240 - this.rocketY) / this.canvasY;
        })
    }
}