import React from 'react';

export default class AnimatedNumber extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            i: 1,
            j: 1
        }
        this.timer = 0;
        this.curveTime = 50;
    }

    componentDidMount() {
        this.animateNumber();
    }

    componentDidUpdate(prevProps) {
        const { animate, onCrashed } = this.props;
        if (prevProps.animate !== animate) {
            if (animate === true) {
                this.setState({
                    i: 1,
                    j: 1
                }, () => {
                    this.animateNumber();
                })
            }
            else if (animate === false) {
                onCrashed();
                clearTimeout(this.timer);
            }
        }
    }

    componentWillUnmount() {
        clearTimeout(this.timer);
    }

    animateNumber = () => {
        const { onNumberChange } = this.props;
        this.timer = setTimeout(() => {
            const { i } = this.state;
            if (i > 10) {
                this.props.onCrashed();
                clearTimeout(this.timer);
                return;
            }
            let num = i + 0.002;
            this.setState({
                i: num,
                j: Math.exp(num - 1)
            }, () => {;
                onNumberChange(this.state.j);
                this.animateNumber();
            })
        }, this.curveTime)
    }

    render() {
        const { j } = this.state;
        return (
            <>{j.toFixed(2)}</>
        )
    }
}