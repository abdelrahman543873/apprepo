import logo from './logo.svg';
import './App.css';
import AnimatedGraph from './AnimatedGraph';
import Test from './Test';

function App() {
	return (
		<div className="App">
			<AnimatedGraph />
		</div>
	);
}

export default App;