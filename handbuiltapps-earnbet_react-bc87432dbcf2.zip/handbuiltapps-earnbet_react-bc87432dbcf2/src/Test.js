import React from 'react';
import ImageSequence from "./AnimatedGraph/ImageSequence";

export default class Test extends React.Component {
    render() {
        return (
            <ImageSequence attribute="clouds" r={require.context('./AnimatedGraph/images/clouds', false, /\.png$/)} />
        )
    }
}